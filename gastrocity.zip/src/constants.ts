import { City } from './types';

export const CITIES: City[] = [
  {
    id: 'tokyo',
    name: 'Tokyo',
    country: 'Japan',
    description: 'The world capital of Michelin stars and street-side ramen.',
    image: 'https://images.unsplash.com/photo-1540959733332-e94e270b2d42?auto=format&fit=crop&q=80&w=800',
    junctions: [
      {
        id: 'j1',
        name: 'Ichiran Ramen',
        type: 'Ramen',
        rating: 4.8,
        description: 'Iconic solo-booth ramen experience with custom bowls.',
        image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5068b?auto=format&fit=crop&q=80&w=400'
      },
      {
        id: 'j2',
        name: 'Sushi Dai',
        type: 'Sushi',
        rating: 4.9,
        description: 'Legendary breakfast sushi at the Toyosu Market.',
        image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&q=80&w=400'
      }
    ]
  },
  {
    id: 'paris',
    name: 'Paris',
    country: 'France',
    description: 'Boulangeries, bistros, and the height of fine dining.',
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&q=80&w=800',
    junctions: [
      {
        id: 'j3',
        name: 'L\'As du Fallafel',
        type: 'Middle Eastern',
        rating: 4.7,
        description: 'The most famous falafel sandwich in Le Marais.',
        image: 'https://images.unsplash.com/photo-1593001874117-c99c4edb888b?auto=format&fit=crop&q=80&w=400'
      }
    ]
  },
  {
    id: 'bangkok',
    name: 'Bangkok',
    country: 'Thailand',
    description: 'A sensory explosion of street food and spicy delights.',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=800',
    junctions: [
      {
        id: 'j4',
        name: 'Jay Fai',
        type: 'Thai Street Food',
        rating: 4.9,
        description: 'Michelin-starred crab omelettes by the legendary Auntie Fai.',
        image: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&q=80&w=400'
      }
    ]
  },
  {
    id: 'new-york',
    name: 'New York City',
    country: 'USA',
    description: 'The ultimate melting pot of global flavors.',
    image: 'https://images.unsplash.com/photo-1496417263034-38ec4f0b665a?auto=format&fit=crop&q=80&w=800',
    junctions: [
      {
        id: 'j5',
        name: 'Katz\'s Delicatessen',
        type: 'Jewish Deli',
        rating: 4.7,
        description: 'World-famous pastrami on rye since 1888.',
        image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&q=80&w=400'
      }
    ]
  }
];
