import { useState } from 'react';
import { motion } from 'motion/react';
import { UtensilsCrossed, Search, ArrowDown } from 'lucide-react';
import CitySection from './components/CitySection';
import GastroGuide from './components/GastroGuide';
import { CITIES } from './constants';

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-40 px-6 py-6 border-b border-white/5 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-orange-500 p-2 rounded-xl">
            <UtensilsCrossed className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white">GastroCity</span>
        </div>
        <div className="hidden md:flex items-center gap-10">
          {['Destinations', 'Food Types', 'Top Junctions', 'Guide'].map((item) => (
            <a key={item} href={`#${item.toLowerCase().replace(' ', '-')}`} className="text-[11px] uppercase tracking-widest font-bold text-zinc-400 hover:text-white transition-colors">
              {item}
            </a>
          ))}
        </div>
        <button className="px-5 py-2.5 bg-white text-black rounded-full text-xs font-bold uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all cursor-pointer">
          Sign In
        </button>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1920" 
          alt="Culinary Scene"
          className="w-full h-full object-cover opacity-40 grayscale-[0.5]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/20 to-black" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="inline-block px-4 py-1.5 bg-orange-500/10 border border-orange-500/20 rounded-full text-orange-500 text-[10px] uppercase tracking-[0.4em] font-bold mb-8">
            The Global Taste Directory
          </span>
          <h1 className="text-6xl md:text-9xl font-light text-white tracking-tighter leading-none mb-8">
            Taste the <span className="italic font-serif bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent">Extraordinary</span>
          </h1>
          <p className="text-zinc-400 text-lg md:text-xl max-w-2xl mx-auto mb-12 font-light leading-relaxed">
            From the bustling markets of Tokyo to the hidden bistros of Paris. Discover the junctions that define global food culture.
          </p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-4">
            <div className="w-full max-w-md relative group">
              <input 
                type="text" 
                placeholder="Search for a city or dish..."
                className="w-full bg-zinc-900/50 backdrop-blur-md border border-white/10 px-8 py-5 rounded-full text-white outline-none focus:border-orange-500/50 transition-all text-sm pr-14"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 bg-orange-500 p-3 rounded-full text-white">
                <Search className="w-4 h-4" />
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 text-zinc-500"
      >
        <span className="text-[10px] uppercase tracking-[0.5em] font-bold">Discover More</span>
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <ArrowDown className="w-4 h-4" />
        </motion.div>
      </motion.div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-black border-t border-zinc-900 py-20 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center gap-2 mb-6">
            <div className="bg-orange-500 p-2 rounded-xl">
              <UtensilsCrossed className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight text-white">GastroCity</span>
          </div>
          <p className="text-zinc-500 max-w-sm text-sm leading-relaxed">
            Your premium guide to the world's most iconic culinary destinations. We find the soul of the city through its plates.
          </p>
        </div>
        <div>
          <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-6">Explore</h4>
          <ul className="space-y-4 text-zinc-500 text-sm">
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Cities</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Junctions</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Culinary Tours</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Chef Stories</li>
          </ul>
        </div>
        <div>
          <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-6">Support</h4>
          <ul className="space-y-4 text-zinc-500 text-sm">
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Contact Us</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Privacy Policy</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Terms of Service</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">FAQ</li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-20 pt-10 border-t border-zinc-900 flex justify-between items-center text-zinc-600 text-[10px] uppercase tracking-widest font-bold">
        <span>© 2026 GastroCity Global. All rights reserved.</span>
        <span>Built with Passion for Taste</span>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-orange-500/30 selection:text-orange-500">
      <Navbar />
      <Hero />
      <div id="destinations">
        <CitySection cities={CITIES} />
      </div>
      <Footer />
      <GastroGuide />
    </div>
  );
}
