export interface FoodJunction {
  id: string;
  name: string;
  type: string;
  rating: number;
  description: string;
  image: string;
}

export interface City {
  id: string;
  name: string;
  country: string;
  description: string;
  image: string;
  junctions: FoodJunction[];
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
