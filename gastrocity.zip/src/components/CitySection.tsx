import { motion } from 'motion/react';
import { Star, MapPin, ChevronRight } from 'lucide-react';
import { City } from '../types';

interface CityCardProps {
  city: City;
  key?: string | number;
}

function CityCard({ city }: CityCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden hover:border-orange-500/30 transition-all duration-500"
    >
      <div className="relative h-64 overflow-hidden">
        <img
          src={city.image}
          alt={city.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent opacity-60" />
        <div className="absolute bottom-4 left-4">
          <div className="flex items-center gap-1.5 text-orange-500 text-[10px] uppercase tracking-widest font-bold mb-1">
            <MapPin className="w-3 h-3" />
            {city.country}
          </div>
          <h3 className="text-2xl font-bold text-white tracking-tight">{city.name}</h3>
        </div>
      </div>
      
      <div className="p-6">
        <p className="text-zinc-400 text-sm leading-relaxed mb-6">
          {city.description}
        </p>
        
        <div className="space-y-4">
          <h4 className="text-[11px] uppercase tracking-[0.2em] font-bold text-zinc-500 px-1">Top Junctions</h4>
          <div className="space-y-3">
            {city.junctions.map((junction) => (
              <div key={junction.id} className="flex items-center gap-3 p-2 rounded-2xl hover:bg-zinc-800/50 transition-colors cursor-pointer group/item">
                <img 
                  src={junction.image} 
                  alt={junction.name}
                  className="w-12 h-12 rounded-xl object-cover grayscale group-hover/item:grayscale-0 transition-all"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-zinc-200 truncate">{junction.name}</p>
                    <div className="flex items-center gap-1 shrink-0">
                      <Star className="w-3 h-3 text-orange-500 fill-orange-500" />
                      <span className="text-[11px] font-mono text-zinc-400">{junction.rating}</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-500 truncate">{junction.type}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-600 group-hover/item:text-orange-500 transition-colors" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function CitySection({ cities }: { cities: City[] }) {
  return (
    <section id="cities-section" className="py-24 px-6 md:px-12 bg-black">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-2xl">
            <span className="text-orange-500 text-xs font-bold uppercase tracking-[0.3em] mb-4 block">Curated Destinations</span>
            <h2 className="text-4xl md:text-6xl font-light text-white tracking-tight leading-tight">
              Culinary Capitals <span className="italic font-serif text-orange-500">of the World</span>
            </h2>
          </div>
          <p className="text-zinc-500 max-w-sm text-sm">
            Hand-picked selections of cities where the food isn't just a meal—it's the main event.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {cities.map((city) => (
            <CityCard key={city.id} city={city} />
          ))}
        </div>
      </div>
    </section>
  );
}
