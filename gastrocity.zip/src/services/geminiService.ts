import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getGastroResponse(prompt: string, history: { role: string; parts: { text: string }[] }[]) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: "user", parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: "You are 'GastroGuide', an enthusiastic culinary expert. Your goal is to guide users through the best food junctions in various cities worldwide. You are polite, helpful, and love sharing interesting food facts. Ask which cities they are looking for if they haven't specified one. Keep responses concise but flavorful.",
      }
    });

    return response.text || "I'm sorry, I couldn't process that culinary request.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a bit of trouble connecting to my recipe book. Please try again in a moment!";
  }
}
